class ArticlesController < ApplicationController
	layout 'default'

	def dashboard
	end
end