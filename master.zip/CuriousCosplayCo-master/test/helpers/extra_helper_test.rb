require 'test_helper'

class ExtraHelperTest < ActionView::TestCase
end
